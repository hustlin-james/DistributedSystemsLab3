# DistributedSystemsLab3
Weather Client XML

Installation:
pip install zeep
pip install xmltodict

Run:
python weather.py

The 4 values that are retrieved are Min/Max Temperature, and Wind Speed/Direction.

